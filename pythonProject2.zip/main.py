from pysnmp.hlapi import *

# Define the file path
file_path = 'target_ips.txt'

# Read target IPs from the file
with open(file_path, 'r') as file:
    target_ips = [line.strip() for line in file]

# Define SNMP SET parameters
oid = '.1.3.6.1.4.1.935.2.1.2.1.2'  # OID for the variable you want to set
value = '10.28.63.210'  # Value you want to set

# Iterate over target IPs
for target_ip in target_ips:
    # Build SNMP SET request
    set_command = setCmd(
        SnmpEngine(),
        CommunityData('public'),  # SNMP community string
        UdpTransportTarget((target_ip, 161)),  # SNMP agent address and port
        ContextData(),
        ObjectType(ObjectIdentity(oid), OctetString(value))
    )

    # Perform SNMP SET operation
    error_indication, error_status, error_index, var_binds = next(set_command)

    # Check for SNMP SET errors
    if error_indication:
        print(f"SNMP SET operation failed for {target_ip}: {error_indication}")
    elif error_status:
        print(f"SNMP SET operation failed for {target_ip}: {error_status.prettyPrint()} at {error_index and var_binds[int(error_index)-1][0] or '?'}")
    else:
        print(f"SNMP SET operation successful for {target_ip}! Value of OID {oid} set to {value}")
